# Info

*   [Porting Ops from Lite to Micro](../docs/porting_reference_ops.md) explains,
    step-by-step, the code changes necessary to port an op from lite to micro,
    and the process of submitting them for review and acceptance by the project.
